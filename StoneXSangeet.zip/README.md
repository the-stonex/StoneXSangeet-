# StoneXSangeet 🎧

StoneXSangeet is a Telegram music bot that streams music in group voice chats.

> 🎵 Inspired by the amazing [AviaxMusic](https://github.com/cyberpixelpro/aviaxmusic)

## 🔥 Features
- Stream from YouTube, Spotify, SoundCloud
- Admin commands
- Playlist support
- Inline query support

## 🚀 Deploy

### Heroku (1-Click)
[![Deploy to Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/the-stonex/StoneXSangeet)

### Manual Deploy
```bash
git clone https://github.com/the-stonex/StoneXSangeet.git
cd StoneXSangeet
pip install -r requirements.txt
python3 main.py
```

## 🛠 Config
Set the following in your `.env` file:
```
API_ID=your_api_id
API_HASH=your_api_hash
BOT_TOKEN=your_bot_token
SESSION_STRING=your_pyrogram_session
OWNER_ID=your_telegram_id
```

## 🙏 Credits
- Based on [AviaxMusic](https://github.com/cyberpixelpro/aviaxmusic)
- Forked & Rebranded by [the-stonex](https://github.com/the-stonex)

---

Ready to bring the beat to your group? 🎶